package com.insideelite.trader

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.*
import com.insideelite.trader.worker.TradeSyncWorker
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class InsideEliteApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        scheduleSyncWorker()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            listOf(
                NotificationChannel(
                    CHANNEL_NEW_TRADES, "New Trade Disclosures",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply { description = "Alerts for new congressional STOCK ACT filings" },
                NotificationChannel(
                    CHANNEL_PRICE_ALERTS, "Price Alerts",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "Watchlist price movement notifications" },
                NotificationChannel(
                    CHANNEL_SYNC, "Background Sync",
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = "Background data synchronisation" }
            ).forEach { manager.createNotificationChannel(it) }
        }
    }

    private fun scheduleSyncWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<TradeSyncWorker>(4, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            TradeSyncWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    companion object {
        const val CHANNEL_NEW_TRADES = "new_trades"
        const val CHANNEL_PRICE_ALERTS = "price_alerts"
        const val CHANNEL_SYNC = "sync"
    }
}
