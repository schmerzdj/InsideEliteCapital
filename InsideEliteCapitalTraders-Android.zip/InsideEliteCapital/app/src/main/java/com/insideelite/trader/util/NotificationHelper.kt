package com.insideelite.trader.util

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.insideelite.trader.InsideEliteApp
import com.insideelite.trader.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val manager = context.getSystemService(NotificationManager::class.java)
    private var notifId = 1000

    private fun launchIntent() = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun showNewTradeNotification(count: Int) {
        val notif = NotificationCompat.Builder(context, InsideEliteApp.CHANNEL_NEW_TRADES)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⚡ $count New Congressional Trade${if (count > 1) "s" else ""}")
            .setContentText("New STOCK ACT filings detected. Tap to view disclosures.")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("$count new congressional trading disclosures have been filed. Open Inside Elite Capital Traders to review risk scores and trade details."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        manager.notify(notifId++, notif)
    }

    fun showPriceAlert(ticker: String, changePct: Double, currentPrice: Double) {
        val dir = if (changePct >= 0) "▲" else "▼"
        val notif = NotificationCompat.Builder(context, InsideEliteApp.CHANNEL_PRICE_ALERTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("$dir $ticker ${String.format("%.1f", changePct)}% Price Alert")
            .setContentText("$ticker is now \$${String.format("%.2f", currentPrice)}")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        manager.notify(notifId++, notif)
    }

    fun showHighRiskAlert(member: String, ticker: String, riskScore: Int) {
        val notif = NotificationCompat.Builder(context, InsideEliteApp.CHANNEL_NEW_TRADES)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("🔴 High-Risk Trade: $member")
            .setContentText("$ticker — Insider risk score: $riskScore%")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(launchIntent())
            .build()
        manager.notify(notifId++, notif)
    }
}

// ── Formatters ────────────────────────────────────────────────────────────────
object Formatters {
    fun formatMoney(amount: Double): String = when {
        amount >= 1_000_000_000 -> "\$${String.format("%.2f", amount / 1_000_000_000)}B"
        amount >= 1_000_000 -> "\$${String.format("%.2f", amount / 1_000_000)}M"
        amount >= 1_000 -> "\$${String.format("%.1f", amount / 1_000)}K"
        else -> "\$${String.format("%.2f", amount)}"
    }
    fun formatMoney(amount: Long) = formatMoney(amount.toDouble())
    fun formatPrice(price: Double) = "\$${String.format("%.2f", price)}"
    fun formatPct(pct: Double) = "${if (pct >= 0) "+" else ""}${String.format("%.1f", pct)}%"
    fun riskLabel(score: Int) = when {
        score >= 85 -> "CRITICAL"
        score >= 70 -> "HIGH"
        score >= 55 -> "ELEVATED"
        score >= 40 -> "MODERATE"
        else -> "LOW"
    }
    fun partyEmoji(party: String) = when (party) { "R" -> "🐘" "D" -> "🫏" else -> "⚖️" }
    fun partyName(party: String) = when (party) { "R" -> "Republican" "D" -> "Democrat" else -> "Independent" }
    fun actionEmoji(action: String) = when (action) { "BUY" -> "▲" "SELL" -> "▼" else -> "⇄" }
}
