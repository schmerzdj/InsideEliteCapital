package com.insideelite.trader.di

import android.content.Context
import androidx.room.Room
import com.insideelite.trader.data.api.ApiConfig
import com.insideelite.trader.data.api.HouseApiService
import com.insideelite.trader.data.api.SenateApiService
import com.insideelite.trader.data.api.StockApiService
import com.insideelite.trader.data.db.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton @Provides
    fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .header("User-Agent", "InsideEliteCapital/2.0 Android")
                .header("Accept", "application/json")
                .build()
            chain.proceed(request)
        }
        .build()

    @Singleton @Provides @Named("house")
    fun provideHouseRetrofit(okHttp: OkHttpClient): Retrofit = Retrofit.Builder()
        .baseUrl(ApiConfig.HOUSE_BASE_URL)
        .client(okHttp)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    @Singleton @Provides @Named("senate")
    fun provideSenateRetrofit(okHttp: OkHttpClient): Retrofit = Retrofit.Builder()
        .baseUrl(ApiConfig.SENATE_BASE_URL)
        .client(okHttp)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    @Singleton @Provides @Named("yahoo")
    fun provideYahooRetrofit(okHttp: OkHttpClient): Retrofit = Retrofit.Builder()
        .baseUrl(ApiConfig.YAHOO_BASE_URL)
        .client(okHttp)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    @Singleton @Provides
    fun provideHouseApi(@Named("house") retrofit: Retrofit): HouseApiService =
        retrofit.create(HouseApiService::class.java)

    @Singleton @Provides
    fun provideSenateApi(@Named("senate") retrofit: Retrofit): SenateApiService =
        retrofit.create(SenateApiService::class.java)

    @Singleton @Provides
    fun provideStockApi(@Named("yahoo") retrofit: Retrofit): StockApiService =
        retrofit.create(StockApiService::class.java)

    @Singleton @Provides
    fun provideDatabase(@ApplicationContext ctx: Context): TradeDatabase =
        Room.databaseBuilder(ctx, TradeDatabase::class.java, "inside_elite.db")
            .fallbackToDestructiveMigration()
            .build()

    @Singleton @Provides fun provideTradeDao(db: TradeDatabase) = db.tradeDao()
    @Singleton @Provides fun provideWatchlistDao(db: TradeDatabase) = db.watchlistDao()
    @Singleton @Provides fun providePortfolioDao(db: TradeDatabase) = db.portfolioDao()
    @Singleton @Provides fun provideAlertDao(db: TradeDatabase) = db.alertDao()
    @Singleton @Provides fun providePriceCacheDao(db: TradeDatabase) = db.priceCacheDao()
}
