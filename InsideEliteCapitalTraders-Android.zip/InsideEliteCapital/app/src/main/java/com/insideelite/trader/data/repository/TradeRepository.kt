package com.insideelite.trader.data.repository

import android.util.Log
import com.insideelite.trader.data.api.HouseApiService
import com.insideelite.trader.data.api.SenateApiService
import com.insideelite.trader.data.api.StockApiService
import com.insideelite.trader.data.db.*
import com.insideelite.trader.data.model.*
import com.insideelite.trader.util.RiskScorer
import com.google.gson.Gson
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TradeRepository @Inject constructor(
    private val houseApi: HouseApiService,
    private val senateApi: SenateApiService,
    private val stockApi: StockApiService,
    private val tradeDao: TradeDao,
    private val watchlistDao: WatchlistDao,
    private val portfolioDao: PortfolioDao,
    private val alertDao: AlertDao,
    private val priceCacheDao: PriceCacheDao
) {
    private val gson = Gson()
    private val TAG = "TradeRepository"

    // ── Trades ────────────────────────────────────────────────────────────────
    fun getAllTrades() = tradeDao.getAllTrades()
    fun getHighRiskTrades() = tradeDao.getHighRiskTrades(70)
    fun getNewTrades() = tradeDao.getNewTrades()
    fun searchTrades(query: String, party: String, action: String, minRisk: Int, sortBy: String) =
        tradeDao.searchTrades(query, party, action, minRisk, sortBy)
    fun getTradesByMember(member: String) = tradeDao.getTradesByMember(member)
    suspend fun getAllMembers() = tradeDao.getAllMembers()
    suspend fun markAllRead() = tradeDao.markAllRead()

    // ── Watchlist ─────────────────────────────────────────────────────────────
    fun getWatchlist() = watchlistDao.getAll()
    suspend fun addToWatchlist(entry: WatchlistEntry) = watchlistDao.upsert(entry)
    suspend fun removeFromWatchlist(entry: WatchlistEntry) = watchlistDao.delete(entry)
    suspend fun isWatchlisted(ticker: String) = watchlistDao.exists(ticker) > 0

    // ── Portfolio ─────────────────────────────────────────────────────────────
    fun getPortfolio() = portfolioDao.getAll()
    fun getPortfolioValue() = portfolioDao.getTotalValue()
    suspend fun upsertPosition(position: PortfolioPosition) = portfolioDao.upsert(position)
    suspend fun deletePosition(position: PortfolioPosition) = portfolioDao.delete(position)

    // ── Alerts ────────────────────────────────────────────────────────────────
    fun getAlerts() = alertDao.getAll()
    fun getUnreadCount() = alertDao.getUnreadCount()
    suspend fun markAlertRead(id: Long) = alertDao.markRead(id)
    suspend fun markAllAlertsRead() = alertDao.markAllRead()
    suspend fun insertAlert(alert: TradeAlert) = alertDao.insert(alert)

    // ── Price cache ───────────────────────────────────────────────────────────
    fun getPrices(tickers: List<String>) = priceCacheDao.getPrices(tickers)

    // ── MAIN SYNC ─────────────────────────────────────────────────────────────
    suspend fun syncAll(): SyncResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        var newTradeCount = 0
        var errors = mutableListOf<String>()

        try {
            // 1. Fetch House trades
            Log.d(TAG, "Fetching House trades…")
            val houseTrades = try {
                houseApi.getAllTransactions()
                    .filter { !it.ticker.isNullOrBlank() && it.ticker != "N/A" && it.ticker != "--" }
                    .takeLast(500) // most recent 500
            } catch (e: Exception) {
                Log.e(TAG, "House API error: ${e.message}")
                errors.add("House API: ${e.message}")
                emptyList()
            }

            // 2. Fetch Senate trades
            Log.d(TAG, "Fetching Senate trades…")
            val senateTrades = try {
                senateApi.getAllTransactions()
                    .filter { !it.ticker.isNullOrBlank() && it.ticker != "N/A" && it.ticker != "--" }
                    .takeLast(300)
            } catch (e: Exception) {
                Log.e(TAG, "Senate API error: ${e.message}")
                errors.add("Senate API: ${e.message}")
                emptyList()
            }

            // 3. Process & enrich House trades
            val processedHouse = houseTrades.mapNotNull { raw ->
                try { processHouseTrade(raw) } catch (e: Exception) { null }
            }

            // 4. Process & enrich Senate trades
            val processedSenate = senateTrades.mapNotNull { raw ->
                try { processSenateTrade(raw) } catch (e: Exception) { null }
            }

            // 5. Identify genuinely new trades
            val existingIds = tradeDao.getAllTrades().first().map { it.id }.toSet()
            val allNew = (processedHouse + processedSenate).filter { it.id !in existingIds }
            newTradeCount = allNew.size

            // 6. Upsert everything
            tradeDao.upsertTrades(processedHouse + processedSenate)

            // 7. Create alerts for new high-risk trades
            allNew.filter { it.riskScore >= 70 }.forEach { trade ->
                alertDao.insert(TradeAlert(
                    type = AlertType.NEW_TRADE,
                    title = "New ${if (trade.riskScore >= 85) "HIGH-RISK " else ""}Disclosure: ${trade.member}",
                    body = "${trade.action} ${trade.ticker} (${trade.company}) — ${trade.amountRange}. Risk score: ${trade.riskScore}%.",
                    ticker = trade.ticker,
                    member = trade.member
                ))
            }

            // 8. Refresh prices for all unique tickers
            val allTickers = (processedHouse + processedSenate)
                .map { it.ticker }
                .filter { it.isNotBlank() && it.length <= 5 }
                .distinct()
                .take(80) // avoid hammering Yahoo
            refreshPrices(allTickers)

            // 9. Evict stale data
            val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(365)
            tradeDao.deleteOlderThan(cutoff)

        } catch (e: Exception) {
            Log.e(TAG, "Sync failed: ${e.message}", e)
            errors.add("Sync: ${e.message ?: "Unknown error"}")
        }

        SyncResult(
            success = errors.isEmpty(),
            newTrades = newTradeCount,
            durationMs = System.currentTimeMillis() - startTime,
            errors = errors
        )
    }

    // ── Price refresh ─────────────────────────────────────────────────────────
    suspend fun refreshPrices(tickers: List<String>) = withContext(Dispatchers.IO) {
        val staleCutoff = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(15)
        tickers.chunked(10).forEach { chunk ->
            chunk.forEach { ticker ->
                try {
                    val cached = priceCacheDao.getPrice(ticker)
                    if (cached != null && cached.updatedAt > staleCutoff) return@forEach

                    val response = stockApi.getQuote(ticker)
                    val meta = response.chart?.result?.firstOrNull()?.meta
                    if (meta != null) {
                        val price = meta.regularMarketPrice ?: return@forEach
                        val prev = meta.previousClose ?: price
                        val change = price - prev
                        val changePct = if (prev > 0) (change / prev * 100) else 0.0

                        priceCacheDao.upsert(PriceCache(
                            ticker = ticker,
                            price = price,
                            change = change,
                            changePct = changePct,
                            dayHigh = meta.regularMarketDayHigh,
                            dayLow = meta.regularMarketDayLow,
                            volume = meta.regularMarketVolume
                        ))
                        // Update in trades and portfolio too
                        tradeDao.updateCurrentPrice(ticker, price)
                        portfolioDao.updatePrice(ticker, price)
                    }
                    delay(120) // ~8 req/s — well within Yahoo's soft limits
                } catch (e: Exception) {
                    Log.w(TAG, "Price fetch failed for $ticker: ${e.message}")
                }
            }
        }
    }

    // ── Process House trade ───────────────────────────────────────────────────
    private fun processHouseTrade(raw: HouseTradeResponse): ProcessedTrade? {
        val member = raw.representative?.trim() ?: return null
        val ticker = raw.ticker?.trim()?.uppercase() ?: return null
        val txDate = raw.transaction_date?.trim() ?: return null
        val discDate = raw.disclosure_date?.trim() ?: return null

        val id = md5("${member}_${ticker}_${txDate}_${raw.amount}")
        val action = normaliseAction(raw.type ?: "")
        val company = raw.asset_description?.trim() ?: ticker
        val sector = RiskScorer.inferSector(ticker, company)
        val owner = raw.owner?.trim() ?: "Self"
        val amount = raw.amount?.trim() ?: "Unknown"
        val amountMid = RiskScorer.parseAmountMid(amount)
        val delay = RiskScorer.calculateDisclosureDelay(txDate, discDate)
        val risk = RiskScorer.score(member, ticker, company, action, amount, txDate, discDate, owner, "House")
        val party = inferParty(member)
        val district = raw.district?.trim() ?: ""
        val state = district.take(2)

        return ProcessedTrade(
            id = id, member = member, chamber = "House", party = party,
            state = state, district = district, ticker = ticker,
            company = company, sector = sector, action = action,
            amountRange = amount, amountMid = amountMid,
            transactionDate = txDate, disclosureDate = discDate,
            disclosureDelayDays = delay, owner = owner,
            riskScore = risk.score, riskFactors = gson.toJson(risk.factors),
            priceAtDisclosure = null, currentPrice = null,
            committee = null, relatedBills = null,
            isNew = false, isFlagged = risk.score >= 70,
            link = raw.link, lastUpdated = System.currentTimeMillis()
        )
    }

    // ── Process Senate trade ──────────────────────────────────────────────────
    private fun processSenateTrade(raw: SenateTradeResponse): ProcessedTrade? {
        val member = raw.senator?.trim() ?: return null
        val ticker = raw.ticker?.trim()?.uppercase() ?: return null
        val txDate = raw.transaction_date?.trim() ?: return null
        val discDate = raw.disclosure_date?.trim() ?: return null

        val id = md5("${member}_${ticker}_${txDate}_${raw.amount}")
        val action = normaliseAction(raw.type ?: "")
        val company = raw.asset_description?.trim() ?: ticker
        val sector = RiskScorer.inferSector(ticker, company)
        val owner = raw.owner?.trim() ?: "Self"
        val amount = raw.amount?.trim() ?: "Unknown"
        val amountMid = RiskScorer.parseAmountMid(amount)
        val delay = RiskScorer.calculateDisclosureDelay(txDate, discDate)
        val risk = RiskScorer.score(member, ticker, company, action, amount, txDate, discDate, owner, "Senate")
        val party = inferParty(member)

        return ProcessedTrade(
            id = id, member = member, chamber = "Senate", party = party,
            state = "", district = null, ticker = ticker,
            company = company, sector = sector, action = action,
            amountRange = amount, amountMid = amountMid,
            transactionDate = txDate, disclosureDate = discDate,
            disclosureDelayDays = delay, owner = owner,
            riskScore = risk.score, riskFactors = gson.toJson(risk.factors),
            priceAtDisclosure = null, currentPrice = null,
            committee = null, relatedBills = null,
            isNew = false, isFlagged = risk.score >= 70,
            link = raw.ptr_link, lastUpdated = System.currentTimeMillis()
        )
    }

    private fun normaliseAction(raw: String): String = when {
        raw.contains("purchase", ignoreCase = true) || raw.contains("buy", ignoreCase = true) -> "BUY"
        raw.contains("sale", ignoreCase = true) || raw.contains("sell", ignoreCase = true) -> "SELL"
        raw.contains("exchange", ignoreCase = true) -> "EXCHANGE"
        else -> raw.uppercase().take(10)
    }

    // Basic party inference from known member names (fallback — real app would use a lookup table)
    private val KNOWN_REPUBLICANS = setOf(
        "tuberville", "wicker", "crenshaw", "capito", "foxx", "burgess", "rubio",
        "mcconnell", "scott", "cotton", "ernst", "collins", "murkowski", "graham",
        "thune", "cornyn", "barrasso", "blunt", "portman", "toomey", "shelby"
    )
    private val KNOWN_DEMOCRATS = setOf(
        "pelosi", "kelly", "gottheimer", "cantwell", "schumer", "warren", "sanders",
        "booker", "klobuchar", "manchin", "sinema", "feinstein", "durbin", "murray",
        "reed", "brown", "casey", "whitehouse", "blumenthal", "markey"
    )

    private fun inferParty(name: String): String {
        val lower = name.lowercase()
        if (KNOWN_REPUBLICANS.any { lower.contains(it) }) return "R"
        if (KNOWN_DEMOCRATS.any { lower.contains(it) }) return "D"
        return "?"
    }

    private fun md5(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // ── Dashboard summary ─────────────────────────────────────────────────────
    suspend fun getDashboardSummary(): DashboardSummary {
        val trades = tradeDao.getAllTrades().first()
        val today = java.time.LocalDate.now().toString()
        return DashboardSummary(
            totalTrades = trades.size,
            highRiskTrades = trades.count { it.riskScore >= 70 },
            totalExposure = trades.sumOf { it.amountMid },
            avgRisk = trades.map { it.riskScore }.average().takeIf { !it.isNaN() } ?: 0.0,
            newToday = trades.count { it.transactionDate.startsWith(today.take(7)) }, // this month
            memberCount = trades.map { it.member }.distinct().size,
            republicanTrades = trades.count { it.party == "R" },
            democratTrades = trades.count { it.party == "D" },
            latestTrades = trades.take(10)
        )
    }
}

data class SyncResult(
    val success: Boolean,
    val newTrades: Int,
    val durationMs: Long,
    val errors: List<String>
)
