package com.insideelite.trader

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.insideelite.trader.ui.screens.*
import com.insideelite.trader.ui.theme.*
import com.insideelite.trader.viewmodel.TradeViewModel
import com.insideelite.trader.worker.TradeSyncWorker
import dagger.hilt.android.AndroidEntryPoint

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Dashboard  : Screen("dashboard",  "Dashboard",  Icons.Default.Home)
    object Trades     : Screen("trades",     "Trades",     Icons.Default.Receipt)
    object Portfolio  : Screen("portfolio",  "Portfolio",  Icons.Default.AccountBalanceWallet)
    object Watchlist  : Screen("watchlist",  "Watchlist",  Icons.Default.Star)
    object Alerts     : Screen("alerts",     "Alerts",     Icons.Default.Notifications)
    object Members    : Screen("members",    "Members",    Icons.Default.People)
}

val NAV_ITEMS = listOf(
    Screen.Dashboard, Screen.Trades, Screen.Portfolio,
    Screen.Watchlist, Screen.Alerts, Screen.Members
)

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* permission result handled silently */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            InsideEliteTheme {
                InsideEliteApp()
            }
        }

        // Trigger first sync
        TradeSyncWorker.scheduleOneTime(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsideEliteApp() {
    val navController = rememberNavController()
    val vm: TradeViewModel = hiltViewModel()
    val uiState by vm.uiState.collectAsState()
    val unreadCount by vm.unreadAlertCount.collectAsState()
    val portfolio by vm.portfolio.collectAsState()

    Scaffold(
        containerColor = EliteColors.Ink1,
        topBar = {
            Column {
                // Masthead
                Surface(
                    color = EliteColors.Ink0,
                    border = BorderStroke(1.dp, EliteColors.Border1)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "Inside Elite Capital Traders",
                                fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold,
                                fontSize = 16.sp, color = EliteColors.Gold
                            )
                            Text(
                                "CONGRESSIONAL TRADE INTELLIGENCE",
                                fontSize = 7.sp, letterSpacing = 2.5.sp,
                                color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Live indicator
                            Surface(
                                color = EliteColors.Down.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, EliteColors.Down.copy(alpha = 0.25f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    val pulse by rememberInfiniteTransition(label = "").animateFloat(
                                        0.3f, 1f, infiniteRepeatable(
                                            tween(900), RepeatMode.Reverse
                                        ), label = "pulse"
                                    )
                                    Box(
                                        modifier = Modifier.size(5.dp).background(
                                            EliteColors.Down.copy(alpha = pulse),
                                            RoundedCornerShape(3.dp)
                                        )
                                    )
                                    Text("LIVE", fontSize = 8.sp, letterSpacing = 2.sp,
                                        color = EliteColors.Down, fontFamily = FontFamily.Monospace)
                                }
                            }
                            // Portfolio value
                            Surface(
                                color = EliteColors.Up.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, EliteColors.Up.copy(alpha = 0.2f))
                            ) {
                                Text(
                                    com.insideelite.trader.util.Formatters.formatMoney(portfolio.totalValue),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    fontSize = 9.sp, letterSpacing = 1.sp,
                                    color = EliteColors.Up, fontFamily = FontFamily.Monospace
                                )
                            }
                            // Sync button
                            if (uiState.isSyncing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = EliteColors.Gold
                                )
                            } else {
                                IconButton(onClick = vm::syncNow, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Refresh, "Sync", tint = EliteColors.Text3, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }

                // Ticker strip
                TickerStrip()
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = EliteColors.Ink0,
                modifier = Modifier.border(BorderStroke(1.dp, EliteColors.Border1))
            ) {
                val currentDest = navController.currentBackStackEntryAsState().value?.destination
                NAV_ITEMS.forEach { screen ->
                    val selected = currentDest?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true; restoreState = true
                            }
                        },
                        icon = {
                            BadgedBox(badge = {
                                if (screen is Screen.Alerts && unreadCount > 0) {
                                    Badge(containerColor = EliteColors.Down) {
                                        Text("$unreadCount", fontSize = 8.sp)
                                    }
                                }
                            }) {
                                Icon(screen.icon, screen.label, modifier = Modifier.size(22.dp))
                            }
                        },
                        label = { Text(screen.label, fontSize = 9.sp, letterSpacing = 0.5.sp, fontFamily = FontFamily.Monospace) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EliteColors.Gold,
                            selectedTextColor = EliteColors.Gold,
                            unselectedIconColor = EliteColors.Text3,
                            unselectedTextColor = EliteColors.Text3,
                            indicatorColor = EliteColors.Gold.copy(alpha = 0.12f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(padding),
            enterTransition = { fadeIn(tween(200)) },
            exitTransition = { fadeOut(tween(150)) }
        ) {
            composable(Screen.Dashboard.route)  { DashboardScreen(vm) }
            composable(Screen.Trades.route)     { TradesScreen(vm) }
            composable(Screen.Portfolio.route)  { PortfolioScreen(vm) }
            composable(Screen.Watchlist.route)  { WatchlistScreen(vm) }
            composable(Screen.Alerts.route)     { AlertsScreen(vm) }
            composable(Screen.Members.route)    { MembersScreen(vm) }
        }
    }
}

@Composable
fun TickerStrip() {
    val tickers = remember {
        listOf("NVDA","RTX","LMT","NOC","PLTR","XOM","PFE","MSFT","GD","AVGO","UNH","AMZN","AAPL","GOOG","META")
    }
    Surface(color = EliteColors.Ink3, border = BorderStroke(1.dp, EliteColors.Border1)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tickers.forEach { sym ->
                val change = remember { (-3f..5f).random() }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(sym, fontSize = 10.sp, fontWeight = FontWeight.Medium,
                        color = EliteColors.Gold2, fontFamily = FontFamily.Monospace)
                    Text(
                        "${if (change >= 0) "+" else ""}${String.format("%.1f", change)}%",
                        fontSize = 9.sp,
                        color = if (change >= 0) EliteColors.Up else EliteColors.Down,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
