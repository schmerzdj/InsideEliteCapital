package com.insideelite.trader.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.insideelite.trader.data.model.*
import com.insideelite.trader.data.repository.TradeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TradeFilter(
    val query: String = "",
    val party: String = "ALL",
    val action: String = "ALL",
    val minRisk: Int = 0,
    val sortBy: String = "date"
)

data class TradeUiState(
    val isLoading: Boolean = false,
    val isSyncing: Boolean = false,
    val lastSyncMs: Long = 0L,
    val syncError: String? = null,
    val newTradeCount: Int = 0
)

data class PortfolioUiState(
    val positions: List<PortfolioPosition> = emptyList(),
    val totalValue: Double = 0.0,
    val totalCost: Double = 0.0,
    val pnl: Double = 0.0,
    val returnPct: Double = 0.0
)

@HiltViewModel
class TradeViewModel @Inject constructor(
    private val repository: TradeRepository
) : ViewModel() {

    // ── UI State ──────────────────────────────────────────────────────────────
    private val _uiState = MutableStateFlow(TradeUiState())
    val uiState = _uiState.asStateFlow()

    private val _filter = MutableStateFlow(TradeFilter())
    val filter = _filter.asStateFlow()

    // ── Trades ────────────────────────────────────────────────────────────────
    @OptIn(ExperimentalCoroutinesApi::class)
    val trades: StateFlow<List<ProcessedTrade>> = _filter.flatMapLatest { f ->
        repository.searchTrades(f.query, f.party, f.action, f.minRisk, f.sortBy)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTrades = repository.getAllTrades()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val highRiskTrades = repository.getHighRiskTrades()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Watchlist ─────────────────────────────────────────────────────────────
    val watchlist = repository.getWatchlist()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Portfolio ─────────────────────────────────────────────────────────────
    val portfolio: StateFlow<PortfolioUiState> = repository.getPortfolio()
        .map { positions ->
            val totalValue = positions.sumOf { it.shares * it.currentPrice }
            val totalCost = positions.sumOf { it.shares * it.avgCost }
            val pnl = totalValue - totalCost
            PortfolioUiState(
                positions = positions,
                totalValue = totalValue,
                totalCost = totalCost,
                pnl = pnl,
                returnPct = if (totalCost > 0) pnl / totalCost * 100 else 0.0
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PortfolioUiState())

    // ── Alerts ────────────────────────────────────────────────────────────────
    val alerts = repository.getAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadAlertCount = repository.getUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // ── Members ───────────────────────────────────────────────────────────────
    private val _members = MutableStateFlow<List<String>>(emptyList())
    val members = _members.asStateFlow()

    // ── Dashboard ─────────────────────────────────────────────────────────────
    private val _dashboard = MutableStateFlow<DashboardSummary?>(null)
    val dashboard = _dashboard.asStateFlow()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            _members.value = repository.getAllMembers()
            _dashboard.value = repository.getDashboardSummary()
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    // ── Actions ───────────────────────────────────────────────────────────────
    fun syncNow() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncing = true, syncError = null) }
            val result = repository.syncAll()
            _dashboard.value = repository.getDashboardSummary()
            _members.value = repository.getAllMembers()
            _uiState.update {
                it.copy(
                    isSyncing = false,
                    lastSyncMs = System.currentTimeMillis(),
                    syncError = if (result.success) null else result.errors.firstOrNull(),
                    newTradeCount = result.newTrades
                )
            }
        }
    }

    fun updateFilter(transform: (TradeFilter) -> TradeFilter) {
        _filter.update(transform)
    }

    fun clearFilter() { _filter.value = TradeFilter() }

    fun addToWatchlist(trade: ProcessedTrade) {
        viewModelScope.launch {
            repository.addToWatchlist(WatchlistEntry(
                ticker = trade.ticker,
                company = trade.company,
                sector = trade.sector,
                addedPrice = trade.currentPrice ?: 0.0,
                currentPrice = trade.currentPrice ?: 0.0,
                inspiredBy = "${trade.member} · ${trade.riskScore}% risk"
            ))
        }
    }

    fun removeFromWatchlist(entry: WatchlistEntry) {
        viewModelScope.launch { repository.removeFromWatchlist(entry) }
    }

    fun buyStock(ticker: String, company: String, sector: String, shares: Double, price: Double, notes: String) {
        viewModelScope.launch {
            val existing = portfolio.value.positions.find { it.ticker == ticker }
            if (existing != null) {
                val totalShares = existing.shares + shares
                val avgCost = (existing.avgCost * existing.shares + price * shares) / totalShares
                repository.upsertPosition(existing.copy(shares = totalShares, avgCost = avgCost))
            } else {
                repository.upsertPosition(PortfolioPosition(
                    ticker = ticker, company = company, sector = sector,
                    shares = shares, avgCost = price, currentPrice = price,
                    inspiredBy = notes.ifBlank { null }, notes = null
                ))
            }
        }
    }

    fun sellStock(ticker: String, shares: Double) {
        viewModelScope.launch {
            val existing = portfolio.value.positions.find { it.ticker == ticker } ?: return@launch
            val remaining = existing.shares - shares
            if (remaining <= 0.0) repository.deletePosition(existing)
            else repository.upsertPosition(existing.copy(shares = remaining))
        }
    }

    fun markAlertRead(id: Long) {
        viewModelScope.launch { repository.markAlertRead(id) }
    }

    fun markAllAlertsRead() {
        viewModelScope.launch { repository.markAllAlertsRead() }
    }

    fun refreshPrices() {
        viewModelScope.launch {
            val tickers = trades.value.map { it.ticker }.distinct().take(50)
            repository.refreshPrices(tickers)
        }
    }
}
