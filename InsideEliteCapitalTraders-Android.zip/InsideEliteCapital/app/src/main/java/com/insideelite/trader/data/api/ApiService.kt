package com.insideelite.trader.data.api

import com.insideelite.trader.data.model.HouseTradeResponse
import com.insideelite.trader.data.model.SenateTradeResponse
import com.insideelite.trader.data.model.YahooQuoteResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

// ── House Stock Watcher (free, no auth) ─────────────────────────────────────
// Source: https://housestockwatcher.com
interface HouseApiService {
    @GET("data/all_transactions.json")
    suspend fun getAllTransactions(): List<HouseTradeResponse>
}

// ── Senate Stock Watcher (free, no auth) ─────────────────────────────────────
// Source: https://senatestockwatcher.com
interface SenateApiService {
    @GET("aggregate/all_transactions.json")
    suspend fun getAllTransactions(): List<SenateTradeResponse>
}

// ── Yahoo Finance (unofficial, no key needed for basic quotes) ───────────────
interface StockApiService {
    @GET("v8/finance/chart/{symbol}")
    suspend fun getQuote(
        @Path("symbol") symbol: String,
        @Query("interval") interval: String = "1d",
        @Query("range") range: String = "5d",
        @Query("includePrePost") includePrePost: Boolean = false
    ): YahooQuoteResponse
}

// ── API base URLs ─────────────────────────────────────────────────────────────
object ApiConfig {
    const val HOUSE_BASE_URL = "https://house-stock-watcher-data.s3-us-west-2.amazonaws.com/"
    const val SENATE_BASE_URL = "https://senate-stock-watcher-data.s3-us-west-2.amazonaws.com/"
    const val YAHOO_BASE_URL = "https://query1.finance.yahoo.com/"
    const val SYNC_INTERVAL_HOURS = 4L
    const val MAX_TRADES_PER_SYNC = 500
    const val PRICE_CACHE_TTL_MINUTES = 15L
}
