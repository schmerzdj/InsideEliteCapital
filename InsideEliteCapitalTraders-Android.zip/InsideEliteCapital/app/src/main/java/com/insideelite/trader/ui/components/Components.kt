package com.insideelite.trader.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.insideelite.trader.data.model.ProcessedTrade
import com.insideelite.trader.data.model.WatchlistEntry
import com.insideelite.trader.ui.theme.*
import com.insideelite.trader.util.Formatters

/* ── KPI Card ────────────────────────────────────────────────────────────── */
@Composable
fun KpiCard(
    label: String,
    value: String,
    sub: String = "",
    accentColor: Color = EliteColors.Gold,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = EliteColors.Ink2,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, EliteColors.Border1)
    ) {
        Box {
            // Top accent line
            Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(accentColor))
            Column(modifier = Modifier.padding(14.dp).padding(top = 2.dp)) {
                Text(
                    label.uppercase(), fontSize = 9.sp, letterSpacing = 2.sp,
                    color = EliteColors.Text3, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Text(
                    value, fontSize = if (value.length > 8) 18.sp else 22.sp,
                    fontWeight = FontWeight.SemiBold, color = EliteColors.Text1,
                    fontStyle = FontStyle.Italic,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (sub.isNotBlank()) {
                    Text(
                        sub, fontSize = 9.sp, color = EliteColors.Text3,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

/* ── Risk Gauge ──────────────────────────────────────────────────────────── */
@Composable
fun RiskGauge(score: Int, modifier: Modifier = Modifier, showLabel: Boolean = true) {
    val color = riskColor(score)
    val animatedProgress by animateFloatAsState(
        targetValue = score / 100f,
        animationSpec = tween(800, easing = EaseOutCubic),
        label = "risk"
    )
    Column(modifier = modifier, horizontalAlignment = Alignment.Start) {
        Text(
            "$score%",
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            color = color, fontStyle = FontStyle.Italic
        )
        if (showLabel) {
            Text(
                Formatters.riskLabel(score).uppercase(),
                fontSize = 7.sp, letterSpacing = 2.sp,
                color = color.copy(alpha = 0.8f), fontFamily = FontFamily.Monospace
            )
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier.fillMaxWidth().height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(EliteColors.Ink4)
        ) {
            Box(modifier = Modifier
                .fillMaxWidth(animatedProgress).fillMaxHeight()
                .clip(RoundedCornerShape(2.dp))
                .background(Brush.horizontalGradient(
                    listOf(color.copy(alpha = 0.6f), color)
                ))
            )
        }
    }
}

/* ── Member Avatar ───────────────────────────────────────────────────────── */
@Composable
fun MemberAvatar(initials: String, color: Color, size: Dp = 40.dp) {
    Box(
        modifier = Modifier.size(size)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.15f))
            .border(1.5.dp, color.copy(alpha = 0.4f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            initials, fontSize = (size.value * 0.28).sp,
            fontWeight = FontWeight.Medium, color = color,
            fontFamily = FontFamily.Monospace
        )
    }
}

fun memberInitials(name: String): String {
    val parts = name.trim().split(" ").filter { it.isNotBlank() }
    return when {
        parts.size >= 2 -> "${parts.first().first()}${parts.last().first()}"
        parts.size == 1 -> parts.first().take(2)
        else -> "??"
    }.uppercase()
}

/* ── Party Badge ─────────────────────────────────────────────────────────── */
@Composable
fun PartyBadge(party: String) {
    val color = partyColor(party)
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(2.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(Formatters.partyEmoji(party), fontSize = 10.sp)
            Text(
                Formatters.partyName(party).uppercase(),
                fontSize = 7.sp, letterSpacing = 1.sp,
                color = color, fontFamily = FontFamily.Monospace
            )
        }
    }
}

/* ── Action Badge ────────────────────────────────────────────────────────── */
@Composable
fun ActionBadge(action: String) {
    val (bg, text) = when (action) {
        "BUY"  -> Pair(EliteColors.Up.copy(alpha = 0.12f), EliteColors.Up)
        "SELL" -> Pair(EliteColors.Down.copy(alpha = 0.12f), EliteColors.Down)
        else   -> Pair(EliteColors.Warn.copy(alpha = 0.12f), EliteColors.Warn)
    }
    Surface(
        color = bg, shape = RoundedCornerShape(2.dp),
        border = BorderStroke(1.dp, text.copy(alpha = 0.3f))
    ) {
        Text(
            "${Formatters.actionEmoji(action)} $action",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            fontSize = 8.sp, letterSpacing = 1.5.sp,
            color = text, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium
        )
    }
}

/* ── Trade Card ──────────────────────────────────────────────────────────── */
@Composable
fun TradeCard(
    trade: ProcessedTrade,
    onClick: () -> Unit,
    onBuy: () -> Unit,
    onSell: () -> Unit,
    onWatch: () -> Unit,
    isExpanded: Boolean = false
) {
    val memberColor = partyColor(trade.party)
    val borderColor = if (trade.isFlagged) EliteColors.Down.copy(alpha = 0.4f) else EliteColors.Border1
    val flagAccent = if (trade.isFlagged) EliteColors.Down else Color.Transparent

    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = if (isExpanded) EliteColors.Ink3 else EliteColors.Ink2,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column {
            // Flag strip for high-risk trades
            if (trade.isFlagged) {
                Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(flagAccent))
            }
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MemberAvatar(memberInitials(trade.member), memberColor, 42.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            trade.member, fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp, color = EliteColors.Text1,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            trade.ticker, fontWeight = FontWeight.Bold,
                            fontSize = 16.sp, color = EliteColors.Gold,
                            fontStyle = FontStyle.Italic
                        )
                    }
                    Spacer(Modifier.height(3.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PartyBadge(trade.party)
                        if (trade.owner.lowercase() != "self") {
                            Surface(
                                color = EliteColors.Warn.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(2.dp),
                                border = BorderStroke(1.dp, EliteColors.Warn.copy(alpha = 0.25f))
                            ) {
                                Text(
                                    "👪 ${trade.owner}",
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 7.sp, color = EliteColors.Warn,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        trade.company, fontSize = 11.sp, color = EliteColors.Text3,
                        fontFamily = FontFamily.Monospace, maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        trade.sector, fontSize = 9.sp, color = EliteColors.Text3.copy(alpha = 0.6f),
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ActionBadge(trade.action)
                    Text(
                        trade.amountRange, fontSize = 9.sp,
                        color = EliteColors.Text2, fontFamily = FontFamily.Monospace,
                        textAlign = androidx.compose.ui.text.style.TextAlign.End
                    )
                    RiskGauge(trade.riskScore, modifier = Modifier.width(80.dp))
                    Text(
                        trade.transactionDate, fontSize = 9.sp,
                        color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                    )
                }
            }
            if (isExpanded) {
                TradeDetailExpanded(trade, onBuy, onSell, onWatch)
            }
        }
    }
}

/* ── Expanded detail ─────────────────────────────────────────────────────── */
@Composable
fun TradeDetailExpanded(trade: ProcessedTrade, onBuy: () -> Unit, onSell: () -> Unit, onWatch: () -> Unit) {
    HorizontalDivider(color = EliteColors.Gold.copy(alpha = 0.2f), thickness = 1.dp)
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

        // Intel box
        Surface(
            color = EliteColors.Down.copy(alpha = 0.05f), shape = RoundedCornerShape(4.dp),
            border = BorderStroke(1.dp, EliteColors.Down.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text("⚠", fontSize = 13.sp)
                    Text(
                        "RISK FACTORS".uppercase(), fontSize = 8.sp,
                        letterSpacing = 2.sp, color = EliteColors.Down,
                        fontFamily = FontFamily.Monospace
                    )
                }
                val factors = try {
                    com.google.gson.Gson().fromJson(trade.riskFactors, Array<String>::class.java)?.toList() ?: emptyList()
                } catch (_: Exception) { emptyList<String>() }
                factors.forEachIndexed { i, factor ->
                    Text(
                        "• $factor",
                        fontSize = 12.sp, color = EliteColors.Text2,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
            }
        }

        // Stats grid
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "Chamber" to trade.chamber,
                "Delay" to "${trade.disclosureDelayDays}d",
                "Account" to trade.owner,
                "Risk" to "${trade.riskScore}%"
            ).forEach { (k, v) ->
                Surface(
                    modifier = Modifier.weight(1f), color = EliteColors.Ink3,
                    shape = RoundedCornerShape(4.dp), border = BorderStroke(1.dp, EliteColors.Border1)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(k.uppercase(), fontSize = 7.sp, letterSpacing = 1.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(4.dp))
                        Text(v, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = EliteColors.Text1)
                    }
                }
            }
        }

        // Action buttons
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onBuy, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EliteColors.Up.copy(alpha = 0.15f),
                    contentColor = EliteColors.Up
                ),
                border = BorderStroke(1.dp, EliteColors.Up.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(4.dp)
            ) { Text("▲ BUY ${trade.ticker}", fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace) }

            Button(
                onClick = onSell, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EliteColors.Down.copy(alpha = 0.15f),
                    contentColor = EliteColors.Down
                ),
                border = BorderStroke(1.dp, EliteColors.Down.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(4.dp)
            ) { Text("▼ SELL ${trade.ticker}", fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace) }

            OutlinedButton(
                onClick = onWatch, shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, EliteColors.Gold.copy(alpha = 0.3f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = EliteColors.Gold)
            ) { Text("☆", fontSize = 14.sp) }
        }
    }
}

/* ── Section Header ──────────────────────────────────────────────────────── */
@Composable
fun SectionHeader(title: String, action: (@Composable () -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            title, fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.SemiBold, fontSize = 18.sp,
            color = EliteColors.Text1
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.weight(1f, fill = false).height(1.dp).background(EliteColors.Border1).widthIn(min = 40.dp, max = 120.dp))
            Spacer(Modifier.width(12.dp))
            action?.invoke()
        }
    }
}

/* ── Sync status banner ──────────────────────────────────────────────────── */
@Composable
fun SyncBanner(isSyncing: Boolean, lastSyncMs: Long, newCount: Int, onSync: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = EliteColors.Ink3,
        border = BorderStroke(1.dp, EliteColors.Border1)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isSyncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        strokeWidth = 1.5.dp,
                        color = EliteColors.Gold
                    )
                    Text("Syncing STOCK ACT filings…", fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                } else {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(
                        if (lastSyncMs > 0) EliteColors.Up else EliteColors.Down
                    ))
                    Text(
                        if (lastSyncMs > 0) {
                            val mins = (System.currentTimeMillis() - lastSyncMs) / 60000
                            "Last sync: ${if (mins < 1) "just now" else "${mins}m ago"}" +
                                    if (newCount > 0) " · $newCount new" else ""
                        } else "Not yet synced",
                        fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                    )
                }
            }
            TextButton(onClick = onSync, enabled = !isSyncing) {
                Text(
                    "↻ SYNC", fontSize = 9.sp, letterSpacing = 1.sp,
                    color = if (isSyncing) EliteColors.Text3 else EliteColors.Gold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

/* ── Stat row ─────────────────────────────────────────────────────────────── */
@Composable
fun StatRow(label: String, value: String, valueColor: Color = EliteColors.Text1) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = EliteColors.Text3)
        Text(value, fontSize = 11.sp, color = valueColor, fontFamily = FontFamily.Monospace)
    }
    HorizontalDivider(color = EliteColors.Border1.copy(alpha = 0.4f), thickness = 0.5.dp)
}

/* ── Benchmark bar ────────────────────────────────────────────────────────── */
@Composable
fun BenchmarkBar(label: String, value: Float, max: Float, color: Color) {
    val progress by animateFloatAsState(value / max, tween(800), label = "bench")
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(label, fontSize = 11.sp, color = EliteColors.Text2, modifier = Modifier.width(110.dp))
        Box(modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(EliteColors.Ink4)) {
            Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(progress).clip(RoundedCornerShape(3.dp)).background(color))
        }
        Text(
            "${if (value >= 0) "+" else ""}${String.format("%.1f", value)}%",
            fontSize = 10.sp, color = color, fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(48.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

/* ── Empty state ─────────────────────────────────────────────────────────── */
@Composable
fun EmptyState(message: String, icon: String = "📭") {
    Column(
        modifier = Modifier.fillMaxWidth().padding(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(icon, fontSize = 36.sp)
        Text(message, fontSize = 16.sp, color = EliteColors.Text3, fontStyle = FontStyle.Italic)
    }
}

/* ── Trade/Order dialog ──────────────────────────────────────────────────── */
@Composable
fun OrderDialog(
    mode: String, // "BUY" or "SELL"
    ticker: String,
    currentPrice: Double?,
    onDismiss: () -> Unit,
    onConfirm: (shares: Double, price: Double, notes: String) -> Unit
) {
    var shares by remember { mutableStateOf("") }
    var price by remember { mutableStateOf(currentPrice?.let { String.format("%.2f", it) } ?: "") }
    var notes by remember { mutableStateOf("") }

    val sharesNum = shares.toDoubleOrNull() ?: 0.0
    val priceNum = price.toDoubleOrNull() ?: 0.0
    val total = sharesNum * priceNum
    val isValid = sharesNum > 0 && priceNum > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = EliteColors.Ink2,
        shape = RoundedCornerShape(8.dp),
        title = {
            Column {
                Text(
                    if (mode == "BUY") "▲ Place Buy Order" else "▼ Place Sell Order",
                    fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold,
                    fontSize = 20.sp, color = EliteColors.Gold2
                )
                Text(
                    ticker, fontSize = 9.sp, letterSpacing = 2.sp,
                    color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = shares, onValueChange = { shares = it },
                        label = { Text("Shares", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = eliteTextFieldColors()
                    )
                    OutlinedTextField(
                        value = price, onValueChange = { price = it },
                        label = { Text("Price ($)", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = eliteTextFieldColors()
                    )
                }
                if (total > 0) {
                    Surface(
                        color = EliteColors.Ink3, shape = RoundedCornerShape(4.dp),
                        border = BorderStroke(1.dp, EliteColors.Border1)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text("Total", fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                                Text(Formatters.formatMoney(total), fontSize = 12.sp, color = EliteColors.Gold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = notes, onValueChange = { notes = it },
                    label = { Text("Notes (optional)", fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("e.g. Following Pelosi NVDA trade", fontSize = 11.sp, color = EliteColors.Text3) },
                    colors = eliteTextFieldColors()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(sharesNum, priceNum, notes) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (mode == "BUY") EliteColors.Up.copy(alpha = 0.2f) else EliteColors.Down.copy(alpha = 0.2f),
                    contentColor = if (mode == "BUY") EliteColors.Up else EliteColors.Down,
                    disabledContainerColor = EliteColors.Ink3
                ),
                border = BorderStroke(1.dp, (if (mode == "BUY") EliteColors.Up else EliteColors.Down).copy(alpha = 0.3f)),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text("Confirm ${if (mode == "BUY") "Purchase" else "Sale"}",
                    fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontSize = 9.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
            }
        }
    )
}

@Composable
fun eliteTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = EliteColors.Gold,
    unfocusedBorderColor = EliteColors.Border1,
    focusedTextColor = EliteColors.Text1,
    unfocusedTextColor = EliteColors.Text1,
    cursorColor = EliteColors.Gold,
    focusedLabelColor = EliteColors.Gold,
    unfocusedLabelColor = EliteColors.Text3,
    focusedContainerColor = EliteColors.Ink3,
    unfocusedContainerColor = EliteColors.Ink3
)
