package com.insideelite.trader.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// ── Raw House Stock Watcher API response ────────────────────────────────────
data class HouseTradeResponse(
    val disclosure_date: String?,
    val transaction_date: String?,
    val owner: String?,
    val ticker: String?,
    val asset_description: String?,
    val asset_type: String?,
    val type: String?,
    val amount: String?,
    val representative: String?,
    val district: String?,
    val link: String?,
    val cap_gains_over_200_usd: Boolean?
)

// ── Raw Senate Stock Watcher API response ───────────────────────────────────
data class SenateTradeResponse(
    val disclosure_date: String?,
    val transaction_date: String?,
    val owner: String?,
    val ticker: String?,
    val asset_description: String?,
    val asset_type: String?,
    val type: String?,
    val amount: String?,
    val senator: String?,
    val ptr_link: String?,
    val comment: String?
)

// ── Yahoo Finance stock quote ────────────────────────────────────────────────
data class YahooQuoteResponse(
    val chart: YahooChart?
)
data class YahooChart(val result: List<YahooResult>?, val error: Any?)
data class YahooResult(
    val meta: YahooMeta?,
    val timestamp: List<Long>?,
    val indicators: YahooIndicators?
)
data class YahooMeta(
    val symbol: String?,
    val regularMarketPrice: Double?,
    val previousClose: Double?,
    val regularMarketDayHigh: Double?,
    val regularMarketDayLow: Double?,
    val regularMarketVolume: Long?,
    val currency: String?
)
data class YahooIndicators(val quote: List<YahooQuote>?)
data class YahooQuote(
    val open: List<Double?>?,
    val high: List<Double?>?,
    val low: List<Double?>?,
    val close: List<Double?>?,
    val volume: List<Long?>?
)

// ── Processed & enriched trade (Room entity) ─────────────────────────────────
@Entity(tableName = "trades")
data class ProcessedTrade(
    @PrimaryKey val id: String,          // hash of member+ticker+date
    val member: String,
    val chamber: String,                 // "House" or "Senate"
    val party: String,                   // "R", "D", "I"
    val state: String,
    val district: String?,
    val ticker: String,
    val company: String,
    val sector: String,
    val action: String,                  // "BUY" or "SELL"
    val amountRange: String,             // e.g. "$15,001 - $50,000"
    val amountMid: Long,                 // midpoint of range in dollars
    val transactionDate: String,
    val disclosureDate: String,
    val disclosureDelayDays: Int,
    val owner: String,                   // "Self", "Spouse", "Joint", etc.
    val riskScore: Int,                  // 0–100 insider probability
    val riskFactors: String,             // JSON array of reasons
    val priceAtDisclosure: Double?,      // stock price when disclosure filed
    val currentPrice: Double?,
    val committee: String?,
    val relatedBills: String?,           // comma-separated
    val isNew: Boolean,                  // true if fetched in last sync
    val isFlagged: Boolean,
    val link: String?,
    val lastUpdated: Long               // epoch millis
)

// ── Watchlist entry (Room entity) ────────────────────────────────────────────
@Entity(tableName = "watchlist")
data class WatchlistEntry(
    @PrimaryKey val ticker: String,
    val company: String,
    val sector: String,
    val addedPrice: Double,
    val currentPrice: Double,
    val alertThresholdPct: Double = 2.0,
    val inspiredBy: String?,
    val addedAt: Long = System.currentTimeMillis()
)

// ── Portfolio position (Room entity) ─────────────────────────────────────────
@Entity(tableName = "portfolio")
data class PortfolioPosition(
    @PrimaryKey val ticker: String,
    val company: String,
    val sector: String,
    val shares: Double,
    val avgCost: Double,
    val currentPrice: Double,
    val inspiredBy: String?,
    val notes: String?,
    val addedAt: Long = System.currentTimeMillis()
)

// ── Alert (Room entity) ──────────────────────────────────────────────────────
@Entity(tableName = "alerts")
data class TradeAlert(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: AlertType,
    val title: String,
    val body: String,
    val ticker: String?,
    val member: String?,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class AlertType { NEW_TRADE, PRICE_MOVE, LATE_DISCLOSURE, PATTERN, BENCHMARK }

// ── Live price cache ─────────────────────────────────────────────────────────
@Entity(tableName = "price_cache")
data class PriceCache(
    @PrimaryKey val ticker: String,
    val price: Double,
    val change: Double,       // absolute
    val changePct: Double,    // percentage
    val dayHigh: Double?,
    val dayLow: Double?,
    val volume: Long?,
    val updatedAt: Long = System.currentTimeMillis()
)

// ── Member stats (computed) ──────────────────────────────────────────────────
data class MemberStats(
    val name: String,
    val party: String,
    val chamber: String,
    val state: String,
    val tradeCount: Int,
    val avgRiskScore: Double,
    val totalExposure: Long,
    val winRate: Double,
    val avgDisclosureDelay: Double,
    val flaggedCount: Int,
    val topSectors: List<String>,
    val trades: List<ProcessedTrade>
)

// ── Dashboard summary (computed) ─────────────────────────────────────────────
data class DashboardSummary(
    val totalTrades: Int,
    val highRiskTrades: Int,
    val totalExposure: Long,
    val avgRisk: Double,
    val newToday: Int,
    val memberCount: Int,
    val republicanTrades: Int,
    val democratTrades: Int,
    val latestTrades: List<ProcessedTrade>
)
