package com.insideelite.trader.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.insideelite.trader.InsideEliteApp
import com.insideelite.trader.data.model.AlertType
import com.insideelite.trader.data.model.TradeAlert
import com.insideelite.trader.data.repository.TradeRepository
import com.insideelite.trader.util.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class TradeSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val repository: TradeRepository,
    private val notificationHelper: NotificationHelper
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val result = repository.syncAll()

            if (result.newTrades > 0) {
                notificationHelper.showNewTradeNotification(result.newTrades)

                // Store a benchmark alert periodically
                if (result.newTrades > 5) {
                    repository.insertAlert(TradeAlert(
                        type = AlertType.BENCHMARK,
                        title = "Sync Complete — ${result.newTrades} new trades",
                        body = "Found ${result.newTrades} new STOCK ACT disclosures. ${result.newTrades} processed in ${result.durationMs}ms.",
                        ticker = null, member = null
                    ))
                }
            }

            if (result.success) Result.success() else Result.retry()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        const val WORK_NAME = "trade_sync_periodic"

        fun scheduleOneTime(context: Context) {
            val request = OneTimeWorkRequestBuilder<TradeSyncWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<TradeSyncWorker>(4, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                TradeSyncWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
