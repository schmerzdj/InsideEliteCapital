package com.insideelite.trader.util

import com.insideelite.trader.data.model.HouseTradeResponse
import com.insideelite.trader.data.model.SenateTradeResponse
import com.google.gson.Gson
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.min

object RiskScorer {

    // Committee → sector mappings: if member sits on committee relevant to stock sector, risk rises
    private val COMMITTEE_SECTOR_MAP = mapOf(
        "armed services" to setOf("defense", "aerospace", "weapons", "military"),
        "energy" to setOf("energy", "oil", "gas", "utility", "coal", "nuclear"),
        "intelligence" to setOf("technology", "data", "surveillance", "ai", "cloud"),
        "commerce" to setOf("technology", "telecommunications", "retail", "transport"),
        "finance" to setOf("banking", "financial", "insurance", "fintech"),
        "health" to setOf("pharmaceutical", "biotech", "medical", "healthcare", "insurance"),
        "judiciary" to setOf("technology", "media", "telecommunications"),
        "foreign relations" to setOf("defense", "aerospace", "energy")
    )

    // Known high-risk members (based on historical patterns & committee positions)
    private val HIGH_RISK_MEMBERS = mapOf(
        "nancy pelosi" to 15,
        "paul pelosi" to 15,
        "tommy tuberville" to 12,
        "roger wicker" to 12,
        "mark kelly" to 10,
        "shelley capito" to 10,
        "virginia foxx" to 8,
        "dan crenshaw" to 8,
        "josh gottheimer" to 8,
        "michael burgess" to 7,
        "maria cantwell" to 8,
        "richard burr" to 15  // was investigated for COVID trades
    )

    // Sectors that carry higher structural risk due to heavy legislation
    private val HIGH_RISK_SECTORS = setOf(
        "defense", "pharmaceutical", "healthcare", "energy", "financial",
        "semiconductor", "artificial intelligence", "cloud", "data"
    )

    // Amount range → midpoint mapping (STOCK ACT ranges)
    val AMOUNT_MAP = mapOf(
        "\$1,001 - \$15,000" to 8000L,
        "\$15,001 - \$50,000" to 32500L,
        "\$50,001 - \$100,000" to 75000L,
        "\$100,001 - \$250,000" to 175000L,
        "\$250,001 - \$500,000" to 375000L,
        "\$500,001 - \$1,000,000" to 750000L,
        "\$1,000,001 - \$5,000,000" to 3000000L,
        "\$5,000,001 - \$25,000,000" to 15000000L,
        "\$25,000,001 - \$50,000,000" to 37500000L,
        "over \$50,000,000" to 50000000L
    )

    data class RiskResult(val score: Int, val factors: List<String>)

    fun score(
        memberName: String,
        ticker: String,
        company: String,
        action: String,
        amountRange: String,
        transactionDate: String,
        disclosureDate: String,
        owner: String,
        chamber: String
    ): RiskResult {
        val factors = mutableListOf<String>()
        var score = 20 // base score

        val memberLower = memberName.lowercase()
        val companyLower = (company + " " + ticker).lowercase()

        // 1. High-risk member history (+0 to +15)
        HIGH_RISK_MEMBERS.entries.firstOrNull { memberLower.contains(it.key) }?.let {
            score += it.value
            factors.add("Member has prior flagged trading history (+${it.value})")
        }

        // 2. Disclosure delay (+0 to +20)
        val delay = calculateDisclosureDelay(transactionDate, disclosureDate)
        when {
            delay > 40 -> { score += 20; factors.add("Disclosure filed ${delay}d after trade — near STOCK Act limit (+20)") }
            delay > 30 -> { score += 15; factors.add("Extended ${delay}d disclosure delay (+15)") }
            delay > 20 -> { score += 10; factors.add("${delay}d disclosure delay (+10)") }
            delay > 14 -> { score += 5;  factors.add("${delay}d disclosure delay (+5)") }
        }

        // 3. Family/spouse account (+10)
        if (owner.lowercase() in listOf("spouse", "joint", "dependent", "child")) {
            score += 10
            factors.add("Filed under ${owner.lowercase()} account — adds separation layer (+10)")
        }

        // 4. Trade size (+0 to +15)
        val amount = AMOUNT_MAP.entries.firstOrNull { amountRange.contains(it.key.replace("\\$", "$")) }?.value ?: 0L
        when {
            amount >= 5_000_000 -> { score += 15; factors.add("Very large position size ≥\$5M (+15)") }
            amount >= 1_000_000 -> { score += 10; factors.add("Large position size ≥\$1M (+10)") }
            amount >= 500_000 -> { score += 7;  factors.add("Significant position size ≥\$500K (+7)") }
            amount >= 100_000 -> { score += 3;  factors.add("Material position size ≥\$100K (+3)") }
        }

        // 5. High-risk sectors (+0 to +10)
        val inHighRiskSector = HIGH_RISK_SECTORS.any { companyLower.contains(it) }
        if (inHighRiskSector) {
            score += 10
            factors.add("Company operates in legislatively sensitive sector (+10)")
        }

        // 6. Senate member in defense stocks (+8)
        if (chamber == "Senate" && (companyLower.contains("defense") || companyLower.contains("raytheon") ||
                    companyLower.contains("lockheed") || companyLower.contains("northrop") ||
                    companyLower.contains("general dynamics") || companyLower.contains("boeing") ||
                    ticker in listOf("LMT", "RTX", "NOC", "GD", "BA", "HII", "KTOS", "AVAV"))) {
            score += 8
            factors.add("Senate Armed Services Committee members buying defense stocks (+8)")
        }

        // 7. Tech stocks near AI/semiconductor legislation (+7)
        if (ticker in listOf("NVDA", "AMD", "AVGO", "INTC", "QCOM", "PLTR", "MSFT", "GOOG", "META", "AMZN")) {
            score += 7
            factors.add("Tech/AI stock during active AI/semiconductor legislative period (+7)")
        }

        // 8. Energy stocks with SPR/ESG legislative context (+6)
        if (ticker in listOf("XOM", "CVX", "COP", "OXY", "HAL", "SLB", "MPC", "VLO") && chamber == "House") {
            score += 6
            factors.add("Energy stock — House Energy & Commerce Committee members (+6)")
        }

        // 9. SELL action before negative news scores higher
        if (action.equals("SELL", ignoreCase = true) || action.equals("Sale", ignoreCase = true)) {
            score += 5
            factors.add("SELL transaction — avoiding future loss is statistically suspicious (+5)")
        }

        return RiskResult(min(score, 99), factors)
    }

    fun calculateDisclosureDelay(transactionDate: String, disclosureDate: String): Int {
        return try {
            val formats = listOf("yyyy-MM-dd", "MM/dd/yyyy", "dd-MMM-yyyy", "yyyy/MM/dd")
            var txDate: LocalDate? = null
            var discDate: LocalDate? = null
            for (fmt in formats) {
                val formatter = DateTimeFormatter.ofPattern(fmt)
                try { if (txDate == null) txDate = LocalDate.parse(transactionDate.trim(), formatter) } catch (_: Exception) {}
                try { if (discDate == null) discDate = LocalDate.parse(disclosureDate.trim(), formatter) } catch (_: Exception) {}
            }
            if (txDate != null && discDate != null)
                ChronoUnit.DAYS.between(txDate, discDate).toInt().coerceAtLeast(0)
            else 0
        } catch (_: Exception) { 0 }
    }

    fun inferSector(ticker: String, company: String): String {
        val c = (company + " " + ticker).lowercase()
        return when {
            ticker in listOf("LMT", "RTX", "NOC", "GD", "BA", "HII", "KTOS", "AVAV", "LDOS", "SAIC") -> "Defense & Aerospace"
            ticker in listOf("NVDA", "AMD", "INTC", "QCOM", "AVGO", "MU", "AMAT", "KLAC") -> "Semiconductors / AI"
            ticker in listOf("PLTR", "PANW", "CRWD", "S", "ZS") -> "Data Intelligence / Cybersecurity"
            ticker in listOf("XOM", "CVX", "COP", "OXY", "HAL", "SLB", "MPC", "VLO") -> "Energy / Oil & Gas"
            ticker in listOf("PFE", "MRK", "ABBV", "JNJ", "BMY", "GILD", "MRNA", "BNTX") -> "Pharmaceuticals"
            ticker in listOf("UNH", "HUM", "CVS", "CI", "CNC", "MOH") -> "Health Insurance"
            ticker in listOf("MSFT", "GOOG", "GOOGL", "META", "AMZN", "AAPL") -> "Big Tech / Cloud"
            ticker in listOf("JPM", "BAC", "GS", "MS", "WFC", "C") -> "Financial Services"
            c.contains("defense") || c.contains("military") || c.contains("weapon") -> "Defense & Aerospace"
            c.contains("pharma") || c.contains("biotech") || c.contains("drug") -> "Pharmaceuticals"
            c.contains("energy") || c.contains("oil") || c.contains("gas") || c.contains("coal") -> "Energy"
            c.contains("tech") || c.contains("software") || c.contains("cloud") -> "Technology"
            c.contains("health") || c.contains("medical") || c.contains("hospital") -> "Healthcare"
            c.contains("bank") || c.contains("financial") || c.contains("capital") -> "Financial Services"
            else -> "Other"
        }
    }

    fun parseAmountMid(amountRange: String): Long {
        val normalised = amountRange.trim().lowercase()
        for ((key, value) in AMOUNT_MAP) {
            if (normalised.contains(key.lowercase().replace("\\$", "$"))) return value
        }
        // Try to parse numbers directly from range
        val numbers = Regex("\\d[\\d,]*").findAll(amountRange)
            .map { it.value.replace(",", "").toLongOrNull() ?: 0L }
            .toList()
        return if (numbers.size >= 2) (numbers[0] + numbers[1]) / 2 else numbers.firstOrNull() ?: 0L
    }
}
