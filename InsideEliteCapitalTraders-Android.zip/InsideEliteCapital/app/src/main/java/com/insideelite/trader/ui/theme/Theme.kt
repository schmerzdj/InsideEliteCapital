package com.insideelite.trader.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ── Colour palette ────────────────────────────────────────────────────────────
object EliteColors {
    // Surfaces
    val Ink0   = Color(0xFF020509)
    val Ink1   = Color(0xFF060C15)
    val Ink2   = Color(0xFF0A1220)
    val Ink3   = Color(0xFF0E182A)
    val Ink4   = Color(0xFF132030)

    // Borders
    val Border1 = Color(0xFF1A2D42)
    val Border2 = Color(0xFF243A52)

    // Brand
    val Gold    = Color(0xFFC8A84B)
    val Gold2   = Color(0xFFE8C86A)
    val Gold3   = Color(0xFF8A6E28)
    val Gold4   = Color(0xFFF5E4A8)

    // Semantic
    val Up      = Color(0xFF22C55E)
    val Down    = Color(0xFFEF4444)
    val Warn    = Color(0xFFF59E0B)
    val Info    = Color(0xFF06B6D4)
    val Blue    = Color(0xFF3B82F6)
    val Blue2   = Color(0xFF60A5FA)
    val Purple  = Color(0xFFA855F7)

    // Text
    val Text1   = Color(0xFFF1F5F9)
    val Text2   = Color(0xFF94A3B8)
    val Text3   = Color(0xFF475569)

    // Risk colours
    val Risk90  = Color(0xFFEF4444)
    val Risk80  = Color(0xFFF97316)
    val Risk70  = Color(0xFFF59E0B)
    val Risk60  = Color(0xFF84CC16)
    val Risk50  = Color(0xFF22C55E)

    // Party
    val RepRed  = Color(0xFFEF4444)
    val DemBlue = Color(0xFF3B82F6)
}

fun riskColor(score: Int) = when {
    score >= 90 -> EliteColors.Risk90
    score >= 80 -> EliteColors.Risk80
    score >= 70 -> EliteColors.Risk70
    score >= 60 -> EliteColors.Risk60
    else        -> EliteColors.Risk50
}

fun partyColor(party: String) = when (party) {
    "R" -> EliteColors.RepRed
    "D" -> EliteColors.DemBlue
    else -> EliteColors.Text3
}

// ── Material 3 colour scheme ──────────────────────────────────────────────────
private val DarkColorScheme = darkColorScheme(
    primary            = EliteColors.Gold,
    onPrimary          = EliteColors.Ink0,
    primaryContainer   = EliteColors.Ink3,
    onPrimaryContainer = EliteColors.Gold2,
    secondary          = EliteColors.Blue,
    onSecondary        = EliteColors.Text1,
    secondaryContainer = EliteColors.Ink3,
    onSecondaryContainer = EliteColors.Blue2,
    tertiary           = EliteColors.Up,
    error              = EliteColors.Down,
    background         = EliteColors.Ink1,
    onBackground       = EliteColors.Text1,
    surface            = EliteColors.Ink2,
    onSurface          = EliteColors.Text1,
    surfaceVariant     = EliteColors.Ink3,
    onSurfaceVariant   = EliteColors.Text2,
    outline            = EliteColors.Border1,
    outlineVariant     = EliteColors.Border2,
)

// ── Typography ────────────────────────────────────────────────────────────────
val EliteTypography = Typography(
    displayLarge  = TextStyle(fontWeight = FontWeight.W300, fontSize = 57.sp, letterSpacing = (-0.25).sp),
    displayMedium = TextStyle(fontWeight = FontWeight.W300, fontSize = 45.sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.W600, fontSize = 32.sp),
    headlineMedium= TextStyle(fontWeight = FontWeight.W600, fontSize = 26.sp, letterSpacing = 0.5.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.W500, fontSize = 20.sp),
    titleLarge    = TextStyle(fontWeight = FontWeight.W600, fontSize = 22.sp),
    titleMedium   = TextStyle(fontWeight = FontWeight.W500, fontSize = 16.sp, letterSpacing = 0.15.sp),
    titleSmall    = TextStyle(fontWeight = FontWeight.W500, fontSize = 14.sp, letterSpacing = 0.1.sp),
    bodyLarge     = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium    = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp),
    bodySmall     = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp),
    labelLarge    = TextStyle(fontWeight = FontWeight.W500, fontSize = 14.sp, letterSpacing = 0.1.sp),
    labelMedium   = TextStyle(fontWeight = FontWeight.W500, fontSize = 12.sp, letterSpacing = 0.5.sp),
    labelSmall    = TextStyle(fontWeight = FontWeight.W500, fontSize = 10.sp, letterSpacing = 1.5.sp),
)

// ── Theme entry point ─────────────────────────────────────────────────────────
@Composable
fun InsideEliteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = EliteTypography,
        content = content
    )
}
