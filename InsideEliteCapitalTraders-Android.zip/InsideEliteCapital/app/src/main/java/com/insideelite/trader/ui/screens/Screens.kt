package com.insideelite.trader.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.insideelite.trader.data.model.*
import com.insideelite.trader.ui.components.*
import com.insideelite.trader.ui.theme.*
import com.insideelite.trader.util.Formatters
import com.insideelite.trader.viewmodel.*

/* ═══════════════════════════════════════════════════════════════════════════
   DASHBOARD SCREEN
═══════════════════════════════════════════════════════════════════════════ */
@Composable
fun DashboardScreen(vm: TradeViewModel) {
    val uiState by vm.uiState.collectAsState()
    val dashboard by vm.dashboard.collectAsState()
    val highRisk by vm.highRiskTrades.collectAsState()
    val unread by vm.unreadAlertCount.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(EliteColors.Ink1),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SyncBanner(
                isSyncing = uiState.isSyncing,
                lastSyncMs = uiState.lastSyncMs,
                newCount = uiState.newTradeCount,
                onSync = vm::syncNow
            )
        }

        item {
            SectionHeader("Command Dashboard")
        }

        // KPI grid
        item {
            dashboard?.let { d ->
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        KpiCard("Trades Tracked", "${d.totalTrades}", "2024 session",
                            EliteColors.Gold, Modifier.weight(1f))
                        KpiCard("High Risk ≥70%", "${d.highRiskTrades}", "Potential insider",
                            EliteColors.Down, Modifier.weight(1f))
                        KpiCard("Total Exposure", Formatters.formatMoney(d.totalExposure),
                            "Combined positions", EliteColors.Blue, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        KpiCard("Avg Risk Score", "${String.format("%.0f", d.avgRisk)}%",
                            "Across all trades", EliteColors.Warn, Modifier.weight(1f))
                        KpiCard("Members Tracked", "${d.memberCount}",
                            "${d.republicanTrades}R / ${d.democratTrades}D", EliteColors.Purple, Modifier.weight(1f))
                        KpiCard("Unread Alerts", "$unread",
                            "Tap Alerts tab", if (unread > 0) EliteColors.Down else EliteColors.Text3, Modifier.weight(1f))
                    }
                }
            } ?: Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = EliteColors.Gold, modifier = Modifier.size(32.dp))
            }
        }

        item {
            // Congress vs Market benchmark
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = EliteColors.Ink2, shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, EliteColors.Border1)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Congress vs Market — YTD", fontSize = 9.sp, letterSpacing = 2.sp,
                        color = EliteColors.Text3, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 12.dp))
                    BenchmarkBar("Congressional Avg", 34.2f, 45f, EliteColors.Gold)
                    BenchmarkBar("🐘 Republican", 38.2f, 45f, EliteColors.RepRed)
                    BenchmarkBar("🫏 Democrat", 29.4f, 45f, EliteColors.DemBlue)
                    BenchmarkBar("S&P 500", 18.6f, 45f, EliteColors.Text3)
                    BenchmarkBar("NASDAQ 100", 21.3f, 45f, EliteColors.Text3)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Congress outperforming S&P 500 by +15.6 percentage points",
                        fontSize = 10.sp, color = EliteColors.Up, fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        item {
            SectionHeader("Latest High-Risk Filings")
        }

        items(highRisk.take(8)) { trade ->
            var expanded by remember { mutableStateOf(false) }
            var orderDialog by remember { mutableStateOf<String?>(null) }

            TradeCard(
                trade = trade,
                onClick = { expanded = !expanded },
                onBuy = { orderDialog = "BUY" },
                onSell = { orderDialog = "SELL" },
                onWatch = { vm.addToWatchlist(trade) },
                isExpanded = expanded
            )

            orderDialog?.let { mode ->
                OrderDialog(
                    mode = mode, ticker = trade.ticker,
                    currentPrice = trade.currentPrice,
                    onDismiss = { orderDialog = null },
                    onConfirm = { shares, price, notes ->
                        if (mode == "BUY") vm.buyStock(trade.ticker, trade.company, trade.sector, shares, price, notes)
                        else vm.sellStock(trade.ticker, shares)
                        orderDialog = null
                    }
                )
            }
        }
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   TRADES SCREEN
═══════════════════════════════════════════════════════════════════════════ */
@Composable
fun TradesScreen(vm: TradeViewModel) {
    val trades by vm.trades.collectAsState()
    val filter by vm.filter.collectAsState()
    val uiState by vm.uiState.collectAsState()
    var expandedId by remember { mutableStateOf<String?>(null) }
    var orderState by remember { mutableStateOf<Pair<String, ProcessedTrade>?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(EliteColors.Ink1)) {
        // Filter bar
        Surface(color = EliteColors.Ink2, border = BorderStroke(1.dp, EliteColors.Border1)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Search
                OutlinedTextField(
                    value = filter.query,
                    onValueChange = { vm.updateFilter { f -> f.copy(query = it) } },
                    placeholder = { Text("Search member, ticker, company…", fontSize = 12.sp, color = EliteColors.Text3) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = eliteTextFieldColors(),
                    shape = RoundedCornerShape(4.dp),
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = EliteColors.Text3, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (filter.query.isNotBlank())
                            IconButton(onClick = { vm.updateFilter { it.copy(query = "") } }) {
                                Icon(Icons.Default.Clear, null, tint = EliteColors.Text3, modifier = Modifier.size(16.dp))
                            }
                    }
                )
                // Filter chips
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("ALL" to "All Parties", "R" to "🐘 Republican", "D" to "🫏 Democrat").forEach { (val, label) ->
                        FilterChip(val, label, filter.party == val) { vm.updateFilter { it.copy(party = val) } }
                    }
                    Spacer(Modifier.width(4.dp))
                    listOf("ALL" to "All", "BUY" to "▲ Buy", "SELL" to "▼ Sell").forEach { (v, l) ->
                        FilterChip(v, l, filter.action == v) { vm.updateFilter { it.copy(action = v) } }
                    }
                    Spacer(Modifier.width(4.dp))
                    listOf(0 to "All Risk", 70 to "High ≥70%", 85 to "Critical ≥85%").forEach { (v, l) ->
                        FilterChip("$v", l, filter.minRisk == v) { vm.updateFilter { it.copy(minRisk = v) } }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${trades.size} results", fontSize = 9.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("date" to "Date", "risk" to "Risk", "amount" to "Amount").forEach { (v, l) ->
                            val selected = filter.sortBy == v
                            TextButton(
                                onClick = { vm.updateFilter { it.copy(sortBy = v) } },
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = if (selected) EliteColors.Gold else EliteColors.Text3
                                )
                            ) { Text("$l${if (selected) " ↓" else ""}", fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace) }
                        }
                    }
                }
            }
        }

        if (uiState.isSyncing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = EliteColors.Gold, trackColor = EliteColors.Ink3)
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (trades.isEmpty()) {
                item { EmptyState("No trades match your filters", "🔍") }
            }
            items(trades, key = { it.id }) { trade ->
                val isExpanded = expandedId == trade.id
                TradeCard(
                    trade = trade,
                    onClick = { expandedId = if (isExpanded) null else trade.id },
                    onBuy = { orderState = "BUY" to trade },
                    onSell = { orderState = "SELL" to trade },
                    onWatch = { vm.addToWatchlist(trade) },
                    isExpanded = isExpanded
                )
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    orderState?.let { (mode, trade) ->
        OrderDialog(
            mode = mode, ticker = trade.ticker, currentPrice = trade.currentPrice,
            onDismiss = { orderState = null },
            onConfirm = { shares, price, notes ->
                if (mode == "BUY") vm.buyStock(trade.ticker, trade.company, trade.sector, shares, price, notes)
                else vm.sellStock(trade.ticker, shares)
                orderState = null
            }
        )
    }
}

@Composable
fun FilterChip(value: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        color = if (selected) EliteColors.Gold.copy(alpha = 0.15f) else Color.Transparent,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (selected) EliteColors.Gold.copy(alpha = 0.4f) else EliteColors.Border1)
    ) {
        Text(
            label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            fontSize = 9.sp, letterSpacing = 1.sp,
            color = if (selected) EliteColors.Gold else EliteColors.Text3,
            fontFamily = FontFamily.Monospace
        )
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   PORTFOLIO SCREEN
═══════════════════════════════════════════════════════════════════════════ */
@Composable
fun PortfolioScreen(vm: TradeViewModel) {
    val portState by vm.portfolio.collectAsState()
    var orderDialog by remember { mutableStateOf<Triple<String, String, Double>?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(EliteColors.Ink1),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionHeader("My Portfolio") }

        // Hero summary
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = EliteColors.Ink2, shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, EliteColors.Border1)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Portfolio Value", fontSize = 9.sp, letterSpacing = 2.sp,
                                color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                            Text(
                                Formatters.formatMoney(portState.totalValue),
                                fontSize = 32.sp, fontWeight = FontWeight.SemiBold,
                                color = EliteColors.Text1, fontStyle = FontStyle.Italic
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Unrealised P&L", fontSize = 9.sp, letterSpacing = 2.sp,
                                color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                            Text(
                                "${if (portState.pnl >= 0) "+" else ""}${Formatters.formatMoney(portState.pnl)}",
                                fontSize = 26.sp, fontWeight = FontWeight.SemiBold,
                                color = if (portState.pnl >= 0) EliteColors.Up else EliteColors.Down,
                                fontStyle = FontStyle.Italic
                            )
                            Text(
                                "${if (portState.returnPct >= 0) "+" else ""}${String.format("%.2f", portState.returnPct)}%",
                                fontSize = 11.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    HorizontalDivider(color = EliteColors.Border1)
                    // Benchmark row
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("vs Benchmark (YTD)", fontSize = 8.sp, letterSpacing = 1.sp,
                            color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                        BenchmarkBar("My Portfolio", portState.returnPct.toFloat().coerceIn(-50f, 80f), 80f, EliteColors.Gold)
                        BenchmarkBar("Congressional", 34.2f, 80f, EliteColors.Up)
                        BenchmarkBar("S&P 500", 18.6f, 80f, EliteColors.Text3)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { orderDialog = Triple("BUY", "", null as Double?) as Triple<String,String,Double>? ?: return@Button },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EliteColors.Up.copy(alpha = 0.15f), contentColor = EliteColors.Up),
                            border = BorderStroke(1.dp, EliteColors.Up.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(4.dp)
                        ) { Text("▲ New Buy", fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace) }
                        Button(
                            onClick = { orderDialog = Triple("SELL", "", 0.0) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EliteColors.Down.copy(alpha = 0.15f), contentColor = EliteColors.Down),
                            border = BorderStroke(1.dp, EliteColors.Down.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(4.dp)
                        ) { Text("▼ New Sell", fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace) }
                    }
                }
            }
        }

        if (portState.positions.isEmpty()) {
            item { EmptyState("No positions. Use the Trades tab to copy politicians' trades.", "💼") }
        }

        items(portState.positions) { pos ->
            val pnl = (pos.currentPrice - pos.avgCost) * pos.shares
            val pct = if (pos.avgCost > 0) (pos.currentPrice - pos.avgCost) / pos.avgCost * 100 else 0.0
            val up = pnl >= 0
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = EliteColors.Ink2, shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, EliteColors.Border1)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(pos.ticker, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                                color = EliteColors.Gold, fontStyle = FontStyle.Italic)
                            Text(pos.company, fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "${if (up) "+" else ""}${Formatters.formatMoney(pnl)}",
                                fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                color = if (up) EliteColors.Up else EliteColors.Down,
                                fontStyle = FontStyle.Italic
                            )
                            Text(
                                "${if (up) "+" else ""}${String.format("%.2f", pct)}%",
                                fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    HorizontalDivider(color = EliteColors.Border1)
                    StatRow("Shares", "${String.format("%.4f", pos.shares)}")
                    StatRow("Avg Cost", Formatters.formatPrice(pos.avgCost))
                    StatRow("Current Price", Formatters.formatPrice(pos.currentPrice), if (pos.currentPrice >= pos.avgCost) EliteColors.Up else EliteColors.Down)
                    StatRow("Market Value", Formatters.formatMoney(pos.shares * pos.currentPrice))

                    // Projections
                    Text("Price Projections", fontSize = 8.sp, letterSpacing = 1.sp,
                        color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                    val rate = 0.12 / 12
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1 to "1M", 3 to "3M", 6 to "6M", 12 to "1Y", 36 to "3Y", 60 to "5Y").forEach { (months, label) ->
                            val projPrice = pos.currentPrice * Math.pow(1 + rate, months.toDouble())
                            val projChg = ((projPrice - pos.currentPrice) / pos.currentPrice * 100).toInt()
                            Surface(
                                modifier = Modifier.weight(1f), color = EliteColors.Ink3,
                                shape = RoundedCornerShape(4.dp), border = BorderStroke(1.dp, EliteColors.Border1)
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Text(label, fontSize = 7.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                                    Text(
                                        Formatters.formatPrice(projPrice),
                                        fontSize = 9.sp, color = EliteColors.Up, fontFamily = FontFamily.Monospace
                                    )
                                    Text("+$projChg%", fontSize = 8.sp, color = EliteColors.Up, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                    pos.inspiredBy?.let {
                        Surface(color = EliteColors.Gold.copy(alpha = 0.06f), shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, EliteColors.Gold.copy(alpha = 0.15f))) {
                            Text("Inspired by: $it", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontSize = 9.sp, color = EliteColors.Gold3, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { orderDialog = Triple("BUY", pos.ticker, pos.currentPrice) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EliteColors.Up.copy(0.12f), contentColor = EliteColors.Up),
                            border = BorderStroke(1.dp, EliteColors.Up.copy(0.3f)), shape = RoundedCornerShape(4.dp)
                        ) { Text("▲ Add", fontSize = 9.sp, fontFamily = FontFamily.Monospace) }
                        Button(
                            onClick = { orderDialog = Triple("SELL", pos.ticker, pos.currentPrice) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EliteColors.Down.copy(0.12f), contentColor = EliteColors.Down),
                            border = BorderStroke(1.dp, EliteColors.Down.copy(0.3f)), shape = RoundedCornerShape(4.dp)
                        ) { Text("▼ Reduce", fontSize = 9.sp, fontFamily = FontFamily.Monospace) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }

    orderDialog?.let { (mode, ticker, price) ->
        OrderDialog(
            mode = mode, ticker = ticker, currentPrice = price,
            onDismiss = { orderDialog = null },
            onConfirm = { shares, p, notes ->
                if (mode == "BUY") vm.buyStock(ticker, ticker, "Technology", shares, p, notes)
                else vm.sellStock(ticker, shares)
                orderDialog = null
            }
        )
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   WATCHLIST SCREEN
═══════════════════════════════════════════════════════════════════════════ */
@Composable
fun WatchlistScreen(vm: TradeViewModel) {
    val watchlist by vm.watchlist.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(EliteColors.Ink1),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { SectionHeader("Watchlist") }

        if (watchlist.isEmpty()) {
            item { EmptyState("No stocks watched. Use ☆ Watch on any trade.", "★") }
        }

        items(watchlist, key = { it.ticker }) { entry ->
            val change = entry.currentPrice - entry.addedPrice
            val changePct = if (entry.addedPrice > 0) change / entry.addedPrice * 100 else 0.0
            val up = changePct >= 0
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = EliteColors.Ink2, shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, EliteColors.Border1)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column {
                            Text(entry.ticker, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                                color = EliteColors.Gold, fontStyle = FontStyle.Italic)
                            Text(entry.company, fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                            Text(entry.sector, fontSize = 9.sp, color = EliteColors.Text3.copy(alpha = 0.6f), fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Formatters.formatPrice(entry.currentPrice), fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold, color = EliteColors.Gold2, fontStyle = FontStyle.Italic)
                            Text(
                                "${if (up) "+" else ""}${String.format("%.1f", changePct)}%",
                                fontSize = 11.sp, color = if (up) EliteColors.Up else EliteColors.Down,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    entry.inspiredBy?.let {
                        Text(it, fontSize = 9.sp, color = EliteColors.Gold3, fontFamily = FontFamily.Monospace)
                    }
                    HorizontalDivider(color = EliteColors.Border1)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = { vm.removeFromWatchlist(entry) },
                            colors = ButtonDefaults.textButtonColors(contentColor = EliteColors.Down)
                        ) { Text("✕ Remove", fontSize = 9.sp, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   ALERTS SCREEN
═══════════════════════════════════════════════════════════════════════════ */
@Composable
fun AlertsScreen(vm: TradeViewModel) {
    val alerts by vm.alerts.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(EliteColors.Ink1),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            SectionHeader("Alerts") {
                TextButton(onClick = vm::markAllAlertsRead) {
                    Text("Mark all read", fontSize = 9.sp, color = EliteColors.Gold, fontFamily = FontFamily.Monospace)
                }
            }
        }

        if (alerts.isEmpty()) {
            item { EmptyState("No alerts yet. Start a sync to detect new filings.", "🔔") }
        }

        items(alerts, key = { it.id }) { alert ->
            val isUnread = !alert.isRead
            val (icon, accentColor) = when (alert.type) {
                AlertType.NEW_TRADE -> "💰" to EliteColors.Gold
                AlertType.PRICE_MOVE -> "📈" to EliteColors.Up
                AlertType.LATE_DISCLOSURE -> "⚠️" to EliteColors.Warn
                AlertType.PATTERN -> "🔴" to EliteColors.Down
                AlertType.BENCHMARK -> "📊" to EliteColors.Blue
            }
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { vm.markAlertRead(alert.id) },
                color = EliteColors.Ink2, shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, if (isUnread) accentColor.copy(alpha = 0.3f) else EliteColors.Border1)
            ) {
                Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (isUnread) Box(modifier = Modifier.width(3.dp).fillMaxHeight().background(accentColor))
                    Box(
                        modifier = Modifier.size(38.dp).background(accentColor.copy(0.12f), RoundedCornerShape(4.dp))
                            .border(1.dp, accentColor.copy(0.2f), RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text(icon, fontSize = 16.sp) }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(alert.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                                color = EliteColors.Text1, modifier = Modifier.weight(1f), maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            if (isUnread) Surface(color = EliteColors.Gold.copy(0.15f), shape = RoundedCornerShape(8.dp)) {
                                Text("NEW", modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                                    fontSize = 7.sp, color = EliteColors.Gold, fontFamily = FontFamily.Monospace)
                            }
                        }
                        Text(alert.body, fontSize = 12.sp, color = EliteColors.Text2, lineHeight = 18.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
                                    .format(java.util.Date(alert.createdAt)),
                                fontSize = 9.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace
                            )
                            alert.ticker?.let {
                                Surface(color = EliteColors.Gold.copy(0.08f), shape = RoundedCornerShape(2.dp),
                                    border = BorderStroke(1.dp, EliteColors.Gold.copy(0.18f))) {
                                    Text(it, modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                                        fontSize = 8.sp, color = EliteColors.Gold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   MEMBERS SCREEN
═══════════════════════════════════════════════════════════════════════════ */
@Composable
fun MembersScreen(vm: TradeViewModel) {
    val allTrades by vm.allTrades.collectAsState()
    val members = remember(allTrades) {
        allTrades.groupBy { it.member }.entries
            .map { (name, trades) ->
                MemberStats(
                    name = name,
                    party = trades.first().party,
                    chamber = trades.first().chamber,
                    state = trades.first().state,
                    tradeCount = trades.size,
                    avgRiskScore = trades.map { it.riskScore }.average().takeIf { !it.isNaN() } ?: 0.0,
                    totalExposure = trades.sumOf { it.amountMid },
                    winRate = 0.0,
                    avgDisclosureDelay = trades.map { it.disclosureDelayDays }.average().takeIf { !it.isNaN() } ?: 0.0,
                    flaggedCount = trades.count { it.isFlagged },
                    topSectors = trades.groupBy { it.sector }.entries.sortedByDescending { it.value.size }.take(2).map { it.key },
                    trades = trades
                )
            }.sortedByDescending { it.avgRiskScore }
    }
    var selectedMember by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(EliteColors.Ink1),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { SectionHeader("Tracked Members — ${members.size}") }

        items(members) { stats ->
            val color = partyColor(stats.party)
            val isSelected = selectedMember == stats.name
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { selectedMember = if (isSelected) null else stats.name },
                color = if (isSelected) EliteColors.Ink3 else EliteColors.Ink2,
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, if (isSelected) color.copy(0.4f) else EliteColors.Border1)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MemberAvatar(memberInitials(stats.name), color, 44.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stats.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = EliteColors.Text1)
                            Text("${stats.chamber} · ${stats.state}", fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                            Spacer(Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                PartyBadge(stats.party)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            RiskGauge(stats.avgRiskScore.toInt(), modifier = Modifier.width(80.dp))
                        }
                    }
                    if (isSelected) {
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = color.copy(0.2f))
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                "Trades" to "${stats.tradeCount}",
                                "Exposure" to Formatters.formatMoney(stats.totalExposure),
                                "Avg Delay" to "${String.format("%.0f", stats.avgDisclosureDelay)}d",
                                "Flagged" to "${stats.flaggedCount}"
                            ).forEach { (k, v) ->
                                Surface(modifier = Modifier.weight(1f), color = EliteColors.Ink4, shape = RoundedCornerShape(4.dp), border = BorderStroke(1.dp, EliteColors.Border1)) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text(k, fontSize = 7.sp, letterSpacing = 1.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                                        Text(v, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = EliteColors.Text1)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Top sectors: ${stats.topSectors.joinToString(" · ")}", fontSize = 10.sp, color = EliteColors.Text3, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}
