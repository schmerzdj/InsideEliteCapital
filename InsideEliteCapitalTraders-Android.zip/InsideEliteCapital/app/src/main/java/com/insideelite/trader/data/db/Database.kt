package com.insideelite.trader.data.db

import androidx.room.*
import com.insideelite.trader.data.model.*
import kotlinx.coroutines.flow.Flow

// ── Type converters ──────────────────────────────────────────────────────────
class Converters {
    @TypeConverter fun alertTypeToString(v: AlertType) = v.name
    @TypeConverter fun stringToAlertType(v: String) = AlertType.valueOf(v)
}

// ── DAOs ─────────────────────────────────────────────────────────────────────
@Dao
interface TradeDao {
    @Query("SELECT * FROM trades ORDER BY transactionDate DESC")
    fun getAllTrades(): Flow<List<ProcessedTrade>>

    @Query("SELECT * FROM trades WHERE riskScore >= :minRisk ORDER BY riskScore DESC")
    fun getHighRiskTrades(minRisk: Int = 70): Flow<List<ProcessedTrade>>

    @Query("SELECT * FROM trades WHERE member = :member ORDER BY transactionDate DESC")
    fun getTradesByMember(member: String): Flow<List<ProcessedTrade>>

    @Query("SELECT * FROM trades WHERE party = :party ORDER BY transactionDate DESC")
    fun getTradesByParty(party: String): Flow<List<ProcessedTrade>>

    @Query("SELECT * FROM trades WHERE isNew = 1 ORDER BY transactionDate DESC")
    fun getNewTrades(): Flow<List<ProcessedTrade>>

    @Query("SELECT * FROM trades WHERE ticker = :ticker ORDER BY transactionDate DESC")
    fun getTradesByTicker(ticker: String): Flow<List<ProcessedTrade>>

    @Query("""
        SELECT * FROM trades WHERE
        (:query = '' OR member LIKE '%' || :query || '%' OR ticker LIKE '%' || :query || '%' OR company LIKE '%' || :query || '%')
        AND (:party = 'ALL' OR party = :party)
        AND (:action = 'ALL' OR action = :action)
        AND (:minRisk = 0 OR riskScore >= :minRisk)
        ORDER BY 
        CASE WHEN :sortBy = 'date' THEN transactionDate END DESC,
        CASE WHEN :sortBy = 'risk' THEN riskScore END DESC,
        CASE WHEN :sortBy = 'amount' THEN amountMid END DESC
    """)
    fun searchTrades(
        query: String = "",
        party: String = "ALL",
        action: String = "ALL",
        minRisk: Int = 0,
        sortBy: String = "date"
    ): Flow<List<ProcessedTrade>>

    @Query("SELECT COUNT(*) FROM trades WHERE isNew = 1")
    suspend fun getNewTradeCount(): Int

    @Query("SELECT COUNT(*) FROM trades")
    suspend fun getTotalCount(): Int

    @Query("SELECT AVG(riskScore) FROM trades")
    suspend fun getAverageRisk(): Double?

    @Query("SELECT SUM(amountMid) FROM trades WHERE action = 'BUY'")
    suspend fun getTotalBuyExposure(): Long?

    @Query("SELECT DISTINCT member FROM trades ORDER BY member ASC")
    suspend fun getAllMembers(): List<String>

    @Upsert
    suspend fun upsertTrades(trades: List<ProcessedTrade>)

    @Query("UPDATE trades SET isNew = 0")
    suspend fun markAllRead()

    @Query("UPDATE trades SET currentPrice = :price WHERE ticker = :ticker")
    suspend fun updateCurrentPrice(ticker: String, price: Double)

    @Query("DELETE FROM trades WHERE lastUpdated < :before")
    suspend fun deleteOlderThan(before: Long)
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY addedAt DESC")
    fun getAll(): Flow<List<WatchlistEntry>>

    @Query("SELECT ticker FROM watchlist")
    suspend fun getAllTickers(): List<String>

    @Upsert suspend fun upsert(entry: WatchlistEntry)
    @Delete suspend fun delete(entry: WatchlistEntry)
    @Query("SELECT COUNT(*) FROM watchlist WHERE ticker = :ticker")
    suspend fun exists(ticker: String): Int
}

@Dao
interface PortfolioDao {
    @Query("SELECT * FROM portfolio ORDER BY addedAt DESC")
    fun getAll(): Flow<List<PortfolioPosition>>

    @Query("SELECT SUM(shares * currentPrice) FROM portfolio")
    fun getTotalValue(): Flow<Double?>

    @Upsert suspend fun upsert(position: PortfolioPosition)
    @Delete suspend fun delete(position: PortfolioPosition)

    @Query("UPDATE portfolio SET currentPrice = :price WHERE ticker = :ticker")
    suspend fun updatePrice(ticker: String, price: Double)

    @Query("SELECT ticker FROM portfolio")
    suspend fun getAllTickers(): List<String>
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM alerts ORDER BY createdAt DESC LIMIT 100")
    fun getAll(): Flow<List<TradeAlert>>

    @Query("SELECT COUNT(*) FROM alerts WHERE isRead = 0")
    fun getUnreadCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(alert: TradeAlert)

    @Query("UPDATE alerts SET isRead = 1 WHERE id = :id")
    suspend fun markRead(id: Long)

    @Query("UPDATE alerts SET isRead = 1")
    suspend fun markAllRead()

    @Query("DELETE FROM alerts WHERE createdAt < :before")
    suspend fun deleteOlderThan(before: Long)
}

@Dao
interface PriceCacheDao {
    @Query("SELECT * FROM price_cache WHERE ticker = :ticker")
    suspend fun getPrice(ticker: String): PriceCache?

    @Query("SELECT * FROM price_cache WHERE ticker IN (:tickers)")
    fun getPrices(tickers: List<String>): Flow<List<PriceCache>>

    @Upsert suspend fun upsert(price: PriceCache)

    @Query("DELETE FROM price_cache WHERE updatedAt < :before")
    suspend fun evictStale(before: Long)
}

// ── Room database ─────────────────────────────────────────────────────────────
@Database(
    entities = [ProcessedTrade::class, WatchlistEntry::class, PortfolioPosition::class, TradeAlert::class, PriceCache::class],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class TradeDatabase : RoomDatabase() {
    abstract fun tradeDao(): TradeDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun portfolioDao(): PortfolioDao
    abstract fun alertDao(): AlertDao
    abstract fun priceCacheDao(): PriceCacheDao
}
