# Inside Elite Capital Traders — Android App
## Congressional Trade Intelligence Platform

A professional Android application that **automatically fetches real STOCK ACT filings** from 
the House and Senate and calculates insider trading risk scores in real time.

---

## Real Data Sources

| Source | URL | Update Frequency |
|--------|-----|-----------------|
| House Stock Watcher | `house-stock-watcher-data.s3-us-west-2.amazonaws.com` | Daily |
| Senate Stock Watcher | `senate-stock-watcher-data.s3-us-west-2.amazonaws.com` | Daily |
| Yahoo Finance (prices) | `query1.finance.yahoo.com` | Live (15-min delay) |

Both watcher APIs are **free, public, and require no API key**. They scrape official 
House and Senate STOCK Act disclosure PDFs and normalise the data daily.

---

## Features

- ✅ **Auto-sync every 4 hours** via WorkManager (background, battery-efficient)
- ✅ **Push notifications** for new high-risk trade disclosures
- ✅ **AI risk scoring** — proprietary algorithm factors committee membership, timing, amount, disclosure delay, and sector
- ✅ **Live stock prices** via Yahoo Finance (no API key needed)
- ✅ **Portfolio tracker** with P&L, projections (1M–5Y), and benchmark vs S&P 500
- ✅ **Watchlist** with price alerts
- ✅ **Member profiles** with aggregated risk stats
- ✅ **Full offline support** via Room database caching
- ✅ **Bloomberg-style dark gold UI** with Jetpack Compose Material 3

---

## Build Instructions

### Requirements
- **Android Studio Hedgehog** (2023.1.1) or newer
- **JDK 17** (bundled with recent Android Studio)
- Android device or emulator running **API 26+** (Android 8.0+)

### Steps

1. **Open in Android Studio**
   ```
   File → Open → select InsideEliteCapital folder
   ```

2. **Let Gradle sync** — all dependencies download automatically (first sync ~2 minutes)

3. **Run on device or emulator**
   ```
   Run → Run 'app'  (or press Shift+F10)
   ```

4. **First launch** — the app immediately triggers a background sync to fetch live data. 
   Pull-to-refresh or tap the ↻ button to force a manual sync.

---

## Architecture

```
InsideEliteCapital/
├── data/
│   ├── api/          Retrofit services (House, Senate, Yahoo Finance)
│   ├── model/        Data classes + Room entities
│   ├── db/           Room database, DAOs
│   └── repository/   Single source of truth
├── ui/
│   ├── theme/        Material 3 dark gold colour scheme
│   ├── components/   Reusable composables (TradeCard, RiskGauge, etc.)
│   └── screens/      Dashboard, Trades, Portfolio, Watchlist, Alerts, Members
├── viewmodel/        Hilt-injected ViewModel with StateFlow
├── worker/           WorkManager periodic sync + BootReceiver
└── util/
    ├── RiskScorer.kt   Insider trading probability algorithm
    ├── Formatters.kt   Currency, percentage, date formatters
    └── NotificationHelper.kt
```

## Risk Scoring Algorithm

The insider risk score (0–100%) is computed from:

| Factor | Max Points |
|--------|-----------|
| Known high-risk member history | +15 |
| Disclosure delay (>40 days) | +20 |
| Family/spouse account | +10 |
| Large position size (≥$5M) | +15 |
| High-risk sector | +10 |
| Senate × defense stocks | +8 |
| Tech/AI stocks in CHIPS period | +7 |
| Energy stocks × House Energy | +6 |
| SELL transaction | +5 |
| Base rate | +20 |

Scores ≥85% are flagged as **CRITICAL**, ≥70% as **HIGH**, ≥55% as **ELEVATED**.

---

## Legal Disclaimer

All data is sourced from publicly available STOCK ACT disclosures. Risk scores represent 
analytical probability assessments — not legal findings of actual insider trading. 
This application is for civic transparency research and investment education only.

The STOCK ACT requires members of Congress to disclose trades within 45 days. 
Violation fine: $200 (widely considered insufficient deterrent).

---

## Dependencies

| Library | Purpose |
|---------|---------|
| Jetpack Compose + Material 3 | UI |
| Hilt | Dependency injection |
| Room | Local database / offline cache |
| Retrofit + OkHttp | HTTP client |
| Gson | JSON parsing |
| WorkManager | Background sync scheduling |
| Kotlin Coroutines + Flow | Async data streams |
